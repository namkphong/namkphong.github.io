# DMX Panel trên Android — cách chạy script

Android có một đường chạy tốt hơn hẳn iPhone: **userscript tự chạy**, không phải
chạm bookmark mỗi lần. File `dmx.user.js` đã gộp cả 2 phần (cào số trên BI +
nạp số vào nv.html) vào một bản cài duy nhất.

---

## Cách A — Firefox + Violentmonkey (khuyên dùng)

Chrome trên Android không cho cài tiện ích. Firefox thì có. Đổi lại anh phải
**đăng nhập BI một lần nữa trong Firefox** — mất 1 phút, sau đó Firefox nhớ luôn.

**Cài (làm 1 lần, ~5 phút):**

1. Cài **Firefox** từ Play Store (bản thường, không phải Focus).
2. Mở Firefox → menu `⋮` → **Tiện ích** (Add-ons) → tìm **Violentmonkey** → **Thêm vào Firefox**.
   (Tampermonkey cũng được, thao tác tương tự.)
3. Đưa file `dmx.user.js` lên repo `namkphong/namkphong.github.io`, commit.
4. Trong Firefox, mở: `https://namkphong.github.io/dmx.user.js`
   → Violentmonkey tự hiện trang cài → bấm **Cài đặt / Install**.
5. Mở `bi.thegioididong.com`, đăng nhập tài khoản MWG của anh.

**Xong.** Từ giờ mỗi lần vào BI sẽ thấy **nút tròn "DMX"** ở góc phải dưới.
Chạm vào là panel bung ra.

**Cập nhật sau này:** anh sửa file trên GitHub, tăng số `@version` ở dòng 3
(1.0.0 → 1.0.1), Violentmonkey tự tải bản mới. Không phải cài lại.

---

## Cách B — Giữ nguyên Chrome, dùng bookmarklet

Nếu anh không muốn đăng nhập lại BI ở trình duyệt khác.

1. Đưa `dmx-panel.js` và `dmx-nap.js` lên GitHub Pages.
2. Chrome → mở trang bất kỳ → `⋮` → dấu ⭐ để lưu dấu trang.
3. `⋮` → **Dấu trang** → giữ vào dấu trang vừa tạo → **Chỉnh sửa**.
4. Đổi **Tên** thành `dmx` và **URL** thành đoạn dưới → Lưu.

```
javascript:(function(){var s=document.createElement('script');s.src='https://namkphong.github.io/dmx-panel.js?v='+Date.now();document.body.appendChild(s);})();
```

Tạo thêm một dấu trang tên `dmxnap` với `dmx-nap.js`.

**Cách chạy:** đang ở trang BI, gõ `dmx` vào thanh địa chỉ → trong danh sách gợi ý
chọn đúng **dấu trang** `dmx` (không phải mục tìm kiếm) → panel bung ra.

Lưu ý thật: Chrome Android đôi khi cắt mất chữ `javascript:` khi dán. Dán xong
kiểm tra lại URL trong ô chỉnh sửa — nếu mất thì gõ tay `javascript:` vào đầu.
Đây là lý do em nghiêng về Cách A.

---

## Cách C — Trình duyệt Chromium có tiện ích

**Lemur Browser** hoặc **Edge Canary** trên Android cài được tiện ích Chrome,
tức là cài được Tampermonkey. Cách làm giống Cách A. Chọn cách này nếu anh quen
giao diện Chromium hơn Firefox. Vẫn phải đăng nhập BI lại trong trình duyệt đó.

---

## Chạy hàng ngày (sau khi cài xong)

1. Mở `bi.thegioididong.com/khoi-ban-hang-sub/-1` → chạm tên **396 Nguyễn Văn Cừ**.
   Đừng gõ thẳng URL `sieu-thi-con?id=…`, BI sẽ đá về trang cụm.
2. Chạm nút **DMX** → dòng "Siêu thị" phải hiện đúng tên → bấm **Lấy số hôm nay**.
   Panel tự: mở tab BC Doanh thu theo nhân viên → mở dấu + → lấy Ô2 → đổi sang
   Chương trình thi đua → lấy Ô3 → sang BC Trả Chậm → lấy Ô4.
3. Quay lại trang cụm → chạm **Ngọc Thụy** → chạm DMX → **Lấy số hôm nay**.
   Số của siêu thị đầu vẫn giữ, không mất khi chuyển trang.
4. Bấm **Đẩy lên Supabase**. Lần đầu hỏi email + mật khẩu, sau đó nhớ token.
5. Mở `namkphong.github.io/nv.html`, đăng nhập → chạm DMX → **Nạp & lưu cả 2 siêu thị**.

Đầu tháng, thêm Ô1: mở `bi.thegioididong.com/thi-dua?id=-1&tab=1&rt=2&dm=1`,
chọn siêu thị, chạm DMX → **Ô1 · Target tháng** → Đẩy lên Supabase.
Ô "TARGET THÁNG SIÊU THỊ" trên nv.html vẫn phải nhập tay.

---

## Chạy thử lần đầu — làm đúng thứ tự này

Đừng bấm "Lấy số hôm nay" ngay. Thử từng nút để biết chỗ nào hỏng:

1. Vào trang siêu thị 396 → chạm DMX → xem dòng **Siêu thị** có hiện tên không.
   Nếu hiện "chưa vào siêu thị" → dừng, chụp màn hình gửi em.
2. Bấm **Chỉ lấy Ô2** → log phải báo `Ô2 ✓ …… ký tự`.
3. Bấm **Chỉ lấy Ô3**, rồi **Chỉ lấy Ô4**.
4. Bấm **Đẩy lên Supabase**.

Có lỗi ở bước nào thì chụp khung log đen gửi em, trong đó ghi rõ selector nào trượt.

| Log báo | Nguyên nhân |
|---|---|
| `Không thấy select chế độ` | Chưa vào trang siêu thị con, hoặc giao diện mobile đổi id |
| `Bảng Chương trình thi đua chưa render` | Mạng chậm — bấm lại nút riêng của Ô3 |
| `Ô… lấy được quá ngắn` | Dấu `+` của BP All In One chưa mở |
| `Đăng nhập Supabase thất bại` | Sai mật khẩu, bấm lại sẽ hỏi lại |

---

## Về bảo mật

Mật khẩu Supabase **không** nằm trong file trên GitHub — file đó công khai, ai
có URL đều đọc được. Panel hỏi lúc chạy rồi lưu token trong máy anh. Đừng
hardcode mật khẩu vào file dù tiện hơn.
